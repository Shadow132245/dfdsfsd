const { Client, Message, EmbedBuilder } = require('discord.js')
const { OwnersId } = require('../Config')

module.exports = {
    name: 'embed',

    /**
     * 
     * @param { Client } Client 
     * @param { Message } Message
     * @param { String[] } Args
     */

    run: async (Client, Message, Args) => {
    if(!OwnersId.includes(Message.author.id)) return;
	  const Embed = new EmbedBuilder()
      .setAuthor({ name: '[English] - Server Rules', iconURL: 'https://cdn.discordapp.com/attachments/1055313728846958622/1065820744694649013/Logo_Png.png'})
      .setColor(`#ffff00`)
      .setImage(``)
      .setDescription(`1 - Do not mention the developers in chat, this bothers them.

2 - Do not promote or share your Discord server links here, this results in an immediate ban!

3 - Do not discuss topics that create controversies such as politics and religions.

4 - Do not go on talking about other Discord bots in this server, this place is only meant for DraxBot

5 - Do not share any Nsfw (Not Safe For Work) content here

6 - If you got any inquiries or issues regarding DraxBot, please consider mentioning the <@&1206717657081061411> role only once,

7 - Repeating messages, images, or mentions is not allowed in here, it is considered as spam and results in getting you muted

8 - Do not mention other Discord server names or talk about their staff, this results in you being warned`)
      .setFooter({ text: Message.guild.name, iconURL: Message.guild.iconURL({dynamic: true})});
      Message.channel.send({embeds: [Embed]})
    }
}