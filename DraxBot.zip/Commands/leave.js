const { Client, Message } = require('discord.js')
const { OwnersId } = require('../Config')

module.exports = {
    name: 'leave',

    /**
     * 
     * @param { Client } Client 
     * @param { Message } Message
     * @param { String[] } Args
     */

    run: async (Client, Message, Args) => {
		if(!OwnersId.includes(Message.author.id)) return;
        const Guild = await Client.guilds.cache.find((Guild) => Guild.id === Args[0])
        if(!Guild) {
            await Message.delete()
            Message.channel.send({ content: `This Guild is not Found in the Client` }).then((Msg) => {
                setTimeout(() => {
                    Msg.delete()
                }, 5000)
            })
        }
        try {
            await Guild.leave()
            Message.channel.send({ content: `${Client.Success} Successfully Leave Server **${Guild.name}**` })
        } catch(Err) {
            console.log(Err)
        }
    }
}