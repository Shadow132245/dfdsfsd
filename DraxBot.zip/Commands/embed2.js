const { Client, Message, EmbedBuilder } = require('discord.js')
const { OwnersId } = require('../Config')

module.exports = {
    name: 'embed2',

    /**
     * 
     * @param { Client } Client 
     * @param { Message } Message
     * @param { String[] } Args
     */

    run: async (Client, Message, Args) => {
    if(!OwnersId.includes(Message.author.id)) return;
	  const Embed = new EmbedBuilder()
      .setAuthor({ name: '[العربي] - قوانين السيرفر', iconURL: 'https://cdn.discordapp.com/attachments/1055313728846958622/1065820744694649013/Logo_Png.png'})
      .setColor(`#ffff00`)
      .setImage(``)
      .setDescription(`القانون الاول : لا تذكر المطورين في الدردشة فهذا يزعجهم

 الثاني : ولا تروج أو تشارك روابط خادم الديسكورد هنا ، فهذا يؤدي إلى حظر فوري

القانون الثالث : لا تناقش مواضيع تثير الجدل كالسياسة والأديان

القانون الرابع : لا تستمر في الحديث عن روبوتات الديسكورد الأخرى في هذا الخادم ، فهذا المكان مخصص لـ دراكس بوت فقط

القانون الخامس : لا تشارك أي محتوى Nsfw (غير آمن للعمل) هنا

القانون السادس : إذا كان لديك أي استفسارات أو مشاكل بخصوص دراكس بوت ، يرجى مراعاة ذكر <@&1206717657081061411> مرة واحدة فقط ،

القانون السابع : لا يُسمح بتكرار الرسائل أو الصور أو الإشارات هنا ، فهو يعتبر بريدًا عشوائيًا ويؤدي إلى كتم صوتك

القانون الثامن : لا تذكر أسماء خوادم الديسكورد الأخرى أو تتحدث عن موظفيها ، فهذا يؤدي إلى تحذيرك`)
      .setFooter({ text: Message.guild.name, iconURL: Message.guild.iconURL({dynamic: true})});
      Message.channel.send({embeds: [Embed]})
    }
}