const { Client, Message, EmbedBuilder } = require('discord.js')
const { OwnersId } = require('../Config.js')

module.exports = {
    name: 'servers',

    /**
     * 
     * @param { Client } Client 
     * @param { Message } Message 
     * @param { String[] } Args
     */

    run: async (Client, Message, Args) => {
		if(!OwnersId.includes(Message.author.id)) return;
       const guilds = Client.guilds.cache.sort((a, b) => b.memberCount -a.memberCount).first(10);
       
       const description = guilds.map((guild, index) => {
         return `\`#${index+1}\` | **${guild.name}** -> **\_\_${guild.memberCount}\_\_** members`
       }).join(`\n\n`)
         
       const embed = new EmbedBuilder()
         .setTitle('Top Guilds')
         .setDescription(description)
         .setColor(`#ffff00`)
         .addFields(
           { name: 'Servers', value: `**${Client.guilds.cache.size}**`, inline: true },
         )
        Message.channel.send({ embeds: [embed] })
    }
}