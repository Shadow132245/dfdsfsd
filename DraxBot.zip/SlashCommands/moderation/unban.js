const { SlashCommandBuilder, Client, ChatInputCommandInteraction } = require('discord.js')

module.exports = {
    data: new SlashCommandBuilder()
    
    .setName('unban')
    .setDescription('Unbans a member.')
    .addStringOption((Option) => Option.setName('value').setDescription('Enter User Id or Type All')),

    /**
     * @param { Client } Client
     * @param { ChatInputCommandInteraction } Interaction
     */

    async execute(Interaction, Client) {
      if (!Interaction.member.permissions.has("BanMembers")) return Interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})
        const Value = Interaction.options.getString('value')
        if(Value === 'All' || Value === 'all' || Value === 'ALL' || Value === 'ALl' || Value === 'الجميع' || Value === 'الكل') {
            await Interaction.guild.bans.fetch().then(async Banned => {
                if(Banned.size === '0') return Interaction.reply({ content: `No Members in the Ban List`, ephemeral: true })
                Banned.forEach(async Member => {
                    await Interaction.guild.members.unban(Member.user)
                    Interaction.reply({ content: `:white_check_mark: **${Banned.size}** members are being unbanned.` })
                })
            })
        } else {
            const User = Client.users.cache.get(Value)
            await Interaction.guild.members.unban(User).then(async() => {
                Interaction.reply({ content: `${User.username} has been Unbanned!` })
            }).catch(() => {
                Interaction.reply({ content: `This Member is not Found in the Bans List`, ephemeral: true })
            })
        }
    }
}