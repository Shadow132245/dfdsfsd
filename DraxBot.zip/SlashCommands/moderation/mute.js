const { SlashCommandBuilder } = require("discord.js");
const ms = require('ms')
module.exports = {
    data:new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Mute Member Guilde')
    .addUserOption(Option => 
        Option
        .setName('user')
        .setDescription('Select Memeber')
        .setRequired(true))
        .addStringOption(option => 
            option
            .setName('time')
            .setDescription('time')
            .setRequired(true)),
            async execute(interaction) {
              if (!interaction.member.permissions.has("MuteMembers")) return interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})
                const User = await interaction.options.getMember('user')
                const Time = await interaction.options.getString('time')
                const Muted = await interaction.guild.roles.cache.find(Muted => Muted.name === 'Muted')
                if(!Muted) return interaction.reply({ content: `I Can't Find Mute Role!`, ephemeral: true })
                if (User.id === interaction.user.id)
                return interaction.reply(`You can't give yourself a die`);
                if (interaction.member.roles.highest.position < User.roles.highest.position)
                return interaction.reply(
                 `You cannot do this to this member because his rank is higher than yours`);
                User.roles.add(Muted)
                interaction.reply({ content: `:white_check_mark: ${User} has been Muted!`})
                setTimeout(() => {
                    User.roles.remove(Muted)
                }, ms(Time))
            }
}