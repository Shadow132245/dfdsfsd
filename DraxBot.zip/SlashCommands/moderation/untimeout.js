const { SlashCommandBuilder } = require('discord.js')
const ms = require('ms');
const humanizeDuration = require('humanize-duration');
module.exports = {
    data: new SlashCommandBuilder()
    .setName('untimeout')
    .setDescription('Removes a timeout from a member.')
    .addUserOption(Option =>
        Option
        .setName('user')
        .setDescription('Select the user')
        .setRequired(true)),
  
            async execute(Interaction, Client) {
               const User = Interaction.options.getMember('user')
if (!Interaction.member.permissions.has("ModerateMembers")) return Interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})

		if(User.user.bot) return Interaction.reply({ content: `**:rolling_eyes: -  You can't untimeout @${User.user.username}.**` })
		
        if(User.user.id === Interaction.member.user.id) return Interaction.reply({ content: `**:rolling_eyes: -  You can't untimeout @${User.user.username}.**` })
        if(Interaction.member.roles.highest.position >= User.roles.highest.position && Interaction.guild.ownerId !== Interaction.member.id) return Interaction.reply({ content: `**:rolling_eyes: -  You can't untimeout @${User.user.username}.**` })

		if(!User.isCommunicationDisabled()) return Interaction.reply({ content: `:x: The member is not timed out.` })

        await User.disableCommunicationUntil(null, `Removed by ${Interaction.user.tag}`)

        Interaction.reply({ content: `**:white_check_mark: @${User.user.username} has been untimed out.**` })
  }
}