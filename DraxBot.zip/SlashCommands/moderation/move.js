const { SlashCommandBuilder } = require("discord.js");
const ms = require('ms')
module.exports = {
    data:new SlashCommandBuilder()
    .setName('move')
    .setDescription('Moves a member to another voice channel')
    .addUserOption(Option => 
        Option
        .setName('user')
        .setDescription('The user to move')
        .setRequired(true))
        .addChannelOption(option => 
            option
            .setName('channel')
            .setDescription('Channel to move the user to.')
            .setRequired(true)),
            async execute(interaction) {
              if (!interaction.member.permissions.has("MoveMembers")) return interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})
   let target = interaction.options.getMember("user");
    let channel = interaction.options.getChannel("channel");
    if(!target.voice.channel) return interaction.reply(`**🙄 - Member is not in voice channel!**`)
    target.voice.setChannel(channel.id).then(c => {
      return interaction.reply({ content:`**✅ ${target.user.username} moved to ${channel.name}!**`})
    });
  }
}