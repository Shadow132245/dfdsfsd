const { Client, SlashCommandBuilder, ChatInputCommandInteraction, ApplicationCommandOptionType } = require('discord.js')
const ms = require('ms');
const humanizeDuration = require('humanize-duration');
module.exports = {
    data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeouts a member')
    .addUserOption(Option =>
        Option
        .setName('user')
        .setDescription('Select the user')
        .setRequired(true))
        .addStringOption(Option =>
            Option
            .setName('time')
            .setDescription('Enter the Time')
            .setRequired(true))
            .addStringOption(Option =>
            Option
            .setName('reason')
            .setDescription('Enter the Reason')
            .setRequired(false)),

    /**
     * @description 
     * @param { Client } Client
     * @param { ChatInputCommandInteraction } Interaction 
     */
  
            async execute(Interaction, Client) {
        const User = Interaction.options.getMember('user')
        const Time = Interaction.options.getString('time')
        const Reason = Interaction.options.getString('reason') || 'No reason provided'

        if (!Interaction.member.permissions.has("ModerateMembers")) return Interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})

        if(User.user.bot) return Interaction.reply({ content: `**:rolling_eyes: -  You can't timeout @${User.user.username}.**`, ephemeral: true })
        if(User.user.id === Interaction.member.user.id) return Interaction.reply({ content: `**:rolling_eyes: -  You can't timeout @${User.user.username}.**` })
        // if(Interaction.member.roles.highest.position >= User.roles.highest.position && Interaction.guild.ownerId !== Interaction.member.id) return Interaction.reply({ content: `**:rolling_eyes: -  You can't ROLES timeout @${User.user.username}.**` })

		const MemberPosition = await User.roles.highest.position;
        const AuthorPosition = await Interaction.member.roles.highest.position;
        const ClientPosition = await Interaction.guild.members.me.roles.highest.position;

        if(AuthorPosition <= MemberPosition) return Interaction.reply({ content: `**:rolling_eyes: -  You can't ROLES timeout @${User.user.username}.**` })
        if(ClientPosition <= MemberPosition) return Interaction.reply({ content: `**:rolling_eyes: -  I can't  timeout @${User.user.username}.**` })
		
        await User.disableCommunicationUntil(Date.now() + ms(Time), `${Reason}`)

        Interaction.reply({ content: `**:white_check_mark: @${User.user.username} has been timed out!**` })
  }
}