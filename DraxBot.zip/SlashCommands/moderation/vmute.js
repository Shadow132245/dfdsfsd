const { SlashCommandBuilder,ChannelType, PermissionFlagsBits } = require("discord.js");

module.exports  = {
    data: new SlashCommandBuilder()
    .setName('vmute')
    .setDescription('Mute a member so they can\'t speak in voice channels.r')
    .addUserOption(option => 
        option 
        .setName('user')
        .setDescription('Select the User')
        .setRequired(true)),

        async execute(Interaction, client,) {
            const Member = Interaction.options.getMember('user')

if (!Interaction.member.permissions.has("MuteMembers")) return Interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})

        if(!Member.voice.channel) return Interaction.reply({ content: `**:rolling_eyes: -  The member is not connected to a voice channel!**` })

        if(Member.user.id === Interaction.member.user.id) return Interaction.reply({ content: `**:rolling_eyes: -  You can't kick @${User.user.username}.**` })
        if(Member.roles.highest.position >= Interaction.member.roles.highest.position && Interaction.guild.ownerId !== Interaction.member.id) return Interaction.reply({ content: `**:rolling_eyes: -  You can't kick @${Member.user.username}.**` })
        if(Member.roles.highest.position >= Interaction.guild.members.me.roles.highest.position && Interaction.guild.ownerId !== Client.user.id) return Interaction.reply({ content: `**:rolling_eyes: -  I can't kick @${Member.user.username}.**` })

        await Member.voice.setMute(true)

        Interaction.reply({ content: `**:white_check_mark: @${Member.user.username} muted from the voice!**` })
    }
}