const { SlashCommandBuilder, ChannelType } = require("discord.js");

module.exports  = {
    data: new SlashCommandBuilder()
    .setName('unvban')
    .setDescription('Voice UnBan For Server')
    .addUserOption(option => 
        option 
        .setName('user')
        .setDescription('Select User')
        .setRequired(true)),

        async execute(interaction, client) {
            if (!interaction.member.permissions.has("BanMembers")) return interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})
            const Member = interaction.options.getUser('user')
          await interaction.guild.channels.cache.forEach((Channel) => {
            if(Channel.type === ChannelType.GuildVoice) {
                Channel.permissionOverwrites.edit(Member, {
                    Connect: true,
                    Speak: true
                })
            }
        })
    interaction.reply({content: `**${Member.username} has been unbanned from voice channel!**`})    
    }
}