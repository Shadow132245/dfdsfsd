const { SlashCommandBuilder, ChannelType, } = require("discord.js");

module.exports  = {
    data: new SlashCommandBuilder()
    .setName('vban')
    .setDescription('Voice Ban For Server')
    .addUserOption(option => 
        option 
        .setName('user')
        .setDescription('Select User Ban')
        .setRequired(true)),

        async execute(interaction, client,) {
           if (!interaction.member.permissions.has("BanMembers")) return interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})
            const Member = interaction.options.getUser('user')
          await interaction.guild.channels.cache.forEach((Channel) => {
            if(Channel.type === ChannelType.GuildVoice) {
                Channel.permissionOverwrites.edit(Member, {
                    Connect: false,
                    Speak: false
                })
            }
        })
    interaction.reply({content: `**${Member.username} has been banned from voice channel!**`})    
    }
}