const { SlashCommandBuilder } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
    .setName('setnick')
    .setDescription('Change Nickname of the Member')
    .addUserOption(Option =>
        Option
        .setName('user')
        .setDescription('Select User')
        .setRequired(true))
        .addStringOption(Option =>
            Option
            .setName('nickname')
            .setDescription('add new nick name')
            .setRequired(true)),
            async execute(Interaction, Client) {
              try {
                      const Member = Interaction.options.getMember('user');
        const NewNickname = Interaction.options.getString('nickname')

        if(Member.roles.highest.position >= Interaction.member.roles.highest.position && Interaction.guild.ownerId !== Interaction.member.id) return Interaction.reply({ content: `:rolling_eyes: -  You couldn't update that user` })
        if(Member.roles.highest.position >= Interaction.guild.members.me.roles.highest.position && Interaction.guild.ownerId !== Client.user.id) return Interaction.reply({ content: `:rolling_eyes: - I couldn't update that user. Please double-check my permissions and role position.` })
        
		if(!NewNickname) {
            await Member.setNickname(Member.user.username)
            Interaction.reply({ content: `:white_check_mark: **${Member.user.username}**'s nick has been reset.` })
        }
        
        await Member.setNickname(NewNickname)
		
        Interaction.reply({ content: `:white_check_mark: **${Member.user.username}**'s nick has been changed to ${NewNickname}!` })
            }catch (err) {
  return Interaction.reply({content: `You are the owner of the server`, ephemeral: true })
  }
 }
}