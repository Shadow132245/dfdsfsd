const { SlashCommandBuilder } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
    .setName('hide-all')
    .setDescription('Hide All Channels'),
    async execute(interaction) {
      if (!interaction.member.permissions.has("ManageChannels")) return interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})
        interaction.guild.channels.cache.each((channel) => { 
            channel.permissionOverwrites.edit(channel.guild.roles.everyone, {
                     ViewChannel : false
                     });
         })
         interaction.reply("> ** Done __Hidedd__ All Server Channels**")
    }

}