const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("unmute")
        .setDescription("Unmute a member from the guild")
        .addUserOption(option =>
            option.setName("target")
                .setDescription("Select the user you wish to unmute.")
                .setRequired(true),
        ),
    async execute(interaction) {
      if (!interaction.member.permissions.has("MuteMembers")) return interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})
        const { guild, options } = interaction;
        const user = options.getUser("target");
        const member = guild.members.cache.get(user.id);
        const Muted = await interaction.guild.roles.cache.find(Muted => Muted.name === 'Muted')
        const errEmbed = new EmbedBuilder()
            .setDescription('Something went wrong. Please try again later.')
            .setColor(0xc72c3b)

        if (member.roles.highest.position >= interaction.member.roles.highest.position)
            return interaction.reply({ embeds: [errEmbed], ephemeral: true });

        try {
            await member.roles.remove(Muted);

            interaction.reply({content: `Succesfully unmuted ${user}`});
        } catch (err) {
            console.log(err);
        }
    }
}