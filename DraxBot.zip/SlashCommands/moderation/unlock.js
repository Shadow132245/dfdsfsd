const { SlashCommandBuilder } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('unlock in channel'),
    async execute(interaction, client) {

     if (!interaction.member.permissions.has("ManageChannels")) return interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})
      let clientMember = await interaction.guild.members.fetch(client.user.id);
      if (!clientMember.permissions.has("ManageChannels")) return interaction.reply({content: `Im Dont Have Permission`, ephemeral: true})
       let everyone = interaction.guild.roles.cache.find(hyper => hyper.name === '@everyone');
        interaction.channel.permissionOverwrites.edit(everyone, {
          SendMessages : true
        }).then(() => {
          interaction.reply({content: `**🔓 ${interaction.channel} Done unlocked this room**`})
        })
    }
}