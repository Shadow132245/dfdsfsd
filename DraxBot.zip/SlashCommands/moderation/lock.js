const { SlashCommandBuilder } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('lock in channel'),
    async execute(interaction, client) {
      if (!interaction.member.permissions.has("ManageChannels")) return interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})
       let everyone = interaction.guild.roles.cache.find(hyper => hyper.name === '@everyone');
        interaction.channel.permissionOverwrites.edit(everyone, {
          SendMessages : false
        }).then(() => {
          interaction.reply({content: `**🔒 ${interaction.channel} Done Locked this room**`,})
        })
    }
}