const { SlashCommandBuilder } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
    .setName('unhide-all')
    .setDescription('unHide All Channels'),

    async execute(interaction) {
      if (!interaction.member.permissions.has("ManageChannels")) return interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})
        interaction.guild.channels.cache.forEach((channel) => { 
            channel.permissionOverwrites.edit(channel.guild.roles.everyone, {
                     ViewChannel : true
                     });
         })
         interaction.reply("** Done __UnHidedd__ All Server Channels**")
    }

}