const { SlashCommandBuilder } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
    .setName('hide')
    .setDescription('Hide Channel'),
    async execute(interaction) {
      if (!interaction.member.permissions.has("ManageChannels")) return interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})
          let everyone = interaction.guild.roles.cache.find(r => r.name === '@everyone');
          interaction.channel.permissionOverwrites.edit(everyone, {
                      ViewChannel : false
                      }).then(() => {
          interaction.reply(`**✅ ${interaction.channel} Done Hided this room.**`)
          })
    }

}