const { SlashCommandBuilder } = require("discord.js");

module.exports ={
    data: new SlashCommandBuilder()
    .setName('vkick')
    .setDescription('Kicks a member from a voice channel')
    .addUserOption(option => 
        option
        .setName('user')
        .setDescription('The user to kick from voice channel')
        .setRequired(true)),
  
           async execute(interaction, client) { 
             if (!interaction.member.permissions.has("MoveMembers")) return interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})
    let target = interaction.options.getMember("user");
    if(!target.voice.channel) return interaction.reply(`**🙄 - Member is not in voice channel!**`)
    if (
      target.roles.highest.position >=
      interaction.member.roles.highest.position
      && interaction.guild.ownerId !== target.id
      && interaction.guild.ownerId !== interaction.member.id
      || interaction.guild.ownerId ==  target.id
    ){
      return interaction.reply({ content: `🙄 - ** You can't kick ${target.user.username}. **`})
      }
      target.voice.setChannel(null).then(c => {
        return interaction.reply({ content:`✅ **${target.user.username} kicked from the voice! **`})
      }).catch(err => {
        return interaction.reply({ content:`🙄 - I couldn't kick that user. Please check my permissions.`})
      })
  }
}