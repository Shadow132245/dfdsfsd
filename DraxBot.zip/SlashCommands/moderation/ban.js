const { SlashCommandBuilder } = require("discord.js");

module.exports ={
    data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Select a member and ban user.')
    .addUserOption(option => 
        option
        .setName('user')
        .setDescription('The member to ban .')
        .setRequired(true))
        .addStringOption(option => 
            option
            .setName('reason')
            .setDescription('the reason for banning')),

        async execute(interaction) {
        const Member = interaction.options.getMember('user')
        const Reason = interaction.options.getString('reason') || 'No reason provided'
        if (!interaction.member.permissions.has("BanMembers")) return interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})
        if(Member.user.id === interaction.member.user.id) return interaction.reply({ content: `**:rolling_eyes: -  You can't ban @${interaction.member.user.username}.**` })
        if(interaction.member.roles.highest.position >= Member.roles.highest.position && interaction.guild.ownerId !== interaction.member.id) return interaction.reply({ content: `**:rolling_eyes: -  You can't ban @${Member.user.username}.**` })
        if(interaction.guild.members.me.roles.highest.position >= Member.roles.highest.position && interaction.guild.ownerId !== interaction.member.id) return interaction.reply({ content: `**:rolling_eyes: -  I can't ban @${Member.user.username}.**` })

        await interaction.guild.members.ban(Member.id, { reason: Reason }).then(() => {
            interaction.reply({ content: `**:white_check_mark: @${Member.user.username} has been banned.**` })
        })
  }
}