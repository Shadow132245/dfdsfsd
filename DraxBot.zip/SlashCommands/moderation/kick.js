const { SlashCommandBuilder } = require("discord.js");

module.exports ={
    data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('kick for member')
    .addUserOption(option => 
        option
        .setName('target')
        .setDescription('The Member to Kick')
        .setRequired(true)),

           async execute(interaction) {
             if (!interaction.member.permissions.has("KickMembers")) return interaction.reply({content:`**😕 You don't have permission **`, ephemeral: true})
            const user = interaction.options.getUser("target");
            const member = await interaction.guild.members.fetch(user.id);
            if (interaction.member.roles.highest.position < member.roles.highest.position)
 return interaction.editReply({content: `You can't take action on ${user.username} since they have a higher role.`});
             await interaction.guild.members.kick(user).catch(err => {
               interaction.reply('Check My Kick')
             });
           await interaction.reply(`✅ **${user.tag} Kicked from the server!**✈️`)
        }
}