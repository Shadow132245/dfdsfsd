const { SlashCommandBuilder, ChatInputCommandInteraction, Client, EmbedBuilder } = require('discord.js')
const fetch = require('node-fetch').default
const moment = require('moment')

module.exports = {
    data: new SlashCommandBuilder()

    .setName('user')
    .setDescription('Shows information, such as ID and join date, about yourself')
    .addUserOption((Option) => Option.setName('user').setDescription('Select the User').setRequired(false)),

    /**
     * @param { Client } client
     * @param { ChatInputCommandInteraction } interaction
     */

    async execute(interaction, client) {
        const Member = interaction.options.getMember('user') || interaction.member;
                 const status = {
       online: 'Online <:onlinestatus:1054749307628171274>',
       offline: 'Offline <:offlinestatus:1054749302519517295>',
       idle: 'Idle <:idlestatus:1054749305837203476>',
       dnd: 'Dnd <:dndstatus:1054749304260141106>'
             };
       
             const flags = {
               DISCORD_EMPLOYEE: "<:staff:1069564356578246667>",
               NITRO : "<:nitro:1069564354594357288>",
               BUGHUNTER_LEVEL_1 : "<:BugHunter:1069564351360553010>",
               BUGHUNTER_LEVEL_2 : "<:BugHunterLvl2:1069564347610841198>",
               HYPESQUAD_EVENTS: "<:HypeSquadEvents:1069564344892923904>",
               HOUSE_BRAVERY: "<:hypesquadbravery:1069564341797523486>",
               HOUSE_BRILLIANCE: "<:HypesquadBrilliance:1069564338312069250>",
               HOUSE_BALANCE: "<:HypesquadBalance:1069564336080699432>",
               EARLY_SUPPORTER: "<:EarlySupporter:1069564332020617277>",
               ACTIVE_DEVELOPER : "<:ActiveDeveloper:1069564326588985374>",
               VERIFIED_BOT: "<:BotVerified:1069564324730908692>",
               EARLY_VERIFIED_BOT_DEVELOPER: "<:EarlyVerifiedBotDeveloper:1069564321958473758>",
               BOOSTER_1: "<:Boosts1:1069564319760658533>",
               BOOSTER_2: "<:Boosts2:1069564316199698545>",
               BOOSTER_3: "<:Boost3:1069564314849128458>",
               BOOSTER_6: "<:Boost4:1069564311657263125>",
               BOOSTER_9: "<:Boost5:1069564309618831395>",
               BOOSTER_12: "<:Boost6:1069564306565386240>",
               BOOSTER_15: "<:Boost7:1069564304791175229>",
               BOOSTER_18: "<:Boost8:1069564301796450304>",
               BOOSTER_24: "<:Boost9:1069564298826895370>",
               PARTNERED_SERVER_OWNER : "<:PartneredServerOwner:1069564296712966154>",
               DISCORD_CERTIFIED_MODERATOR : "<:DiscordCertifiedModerator:1069564292820635668>",
             };
       
       
             const response = await fetch(
              `https://japi.rest/discord/v1/user/${Member.id}`
             );
             const data = await response.json(); 
         
         
             const badges = data.data.public_flags_array
             ? data.data.public_flags_array.map((flag) => flags[flag]).join(" ")
                : "No Badges.";
       
       
         
         let embed = new EmbedBuilder()
       
          .addFields({name: `Username :`, value: `${Member.user.username}`, inline: true})
         
                .addFields({name: `Tag :`, value: `${Member.user.discriminator}`, inline: true})
       
           
            .addFields({name: `User id :`, value: `${Member.id}`, inline: true})
       
        .addFields({name: `Nickname :`, value: Member.nickname || "None", inline: true})
           
            .addFields({name: `Bot :`, value: Member.bot ? 'true' : 'false', inline: true})
       
       .addFields({name: `States :`, value: status[interaction.guild.members.cache.find(e => e.id == Member.id).presence?.status || 'offline'], inline: true})
       
       .addFields({name: `Joined Discord :`, value: `<t:${parseInt(Member.user.createdAt / 1000)}:R>`, inline: true})
           
       .addFields({ name: 'Joined Server', value: `<t:${parseInt(Member.joinedAt / 1000)}:R>`, inline: true })
       
       .addFields({name : `Badge :` , value: badges || `No Badges`, inline: true})     
       .setColor(`Random`)                                                                      
      .setAuthor({ name: `${Member.user.tag}`, iconURL: Member.user.displayAvatarURL() })
           .setThumbnail(Member.displayAvatarURL({dynamic:true}))
           
       .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
             
           interaction.reply({ embeds: [embed] }).catch((err) => {
                                                       console.log(`i couldn't reply to the message: ` + err.message)
           
                                             })
           }
        }