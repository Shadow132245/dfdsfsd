const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder } = require("discord.js");

module.exports = {
    data: new SlashCommandBuilder()
    .setName('tax')
    .setDescription('Calculates The Tax Probot')
    .addIntegerOption(Option => 
        Option
        .setName('amount')
        .setDescription('Add Number')
        .setRequired(true)),

        async execute(interaction) {
            try {
                let args2 = interaction.options.getInteger('amount')
          
                let tax = Math.floor(args2 * (20) / (19) + (1))
                let tax2 = Math.floor(args2 * (20) / (19) + (1)-(args2))
                let tax3 = Math.floor(tax2 * (20) / (19) + (1))
                let tax4 = Math.floor(tax2 + tax3 + args2)
                let errorembed3 = new EmbedBuilder()
                .setTitle(`**Error**`)
                .setColor("Random")
                .setDescription(`**It Must be a Number**`)
                .setTimestamp()
                .setFooter({text: `Requested by ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic: true})})
          
                let errorembed2 = new EmbedBuilder()
                .setTitle(`**Error**`)
                .setColor("Random")
                .setDescription(`**Must Be A Number**`)
                .setTimestamp()
                .setFooter({text: `Requested by ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic: true})})
                if (isNaN(args2)) return interaction.reply({embeds:[errorembed2]});
                let errorembed = new EmbedBuilder()
                .setTitle(`**Error**`)
                .setColor("Random")
                .setDescription(`**Must The Number Larger 1**`)
                .setTimestamp()
                .setFooter({text: `Requested by ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic: true})})
                if (args2 < 1) return interaction.reply({embeds:[errorembed]});
                let tax_embed = new EmbedBuilder()
                .setColor("Random")
                .setThumbnail(interaction.guild.iconURL())
                .setTimestamp()
                .setAuthor({name: interaction.user.username, iconURL: interaction.user.avatarURL()})
                .setDescription(`
                > **💰 __Your Tax is : __${tax} **`)
                .setFooter({text: `Requested by ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic: true})})
                
                let mod_embed = new EmbedBuilder()
                .setColor('Random')
                .setThumbnail(interaction.guild.iconURL())
                .setTimestamp()
                .setAuthor({name: interaction.user.username, iconURL: interaction.user.avatarURL()})
                .setDescription(`
                > **👮 __Your Tax With Mediator is : __${tax4} **
                `)
                .setFooter({text: `Requested by ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic: true})})
                  let row = new ActionRowBuilder()
                      .addComponents(
                                  new ButtonBuilder()
                  .setCustomId(`first_embed`)
                  .setLabel("Mediator")
                  .setEmoji("👮")
                  .setStyle('Success')
                );
                let row2 = new ActionRowBuilder()
                      .addComponents(
                  new ButtonBuilder()
                  .setCustomId(`2_embed`)
                  .setLabel("Back")
                  .setEmoji("↩️")
                  .setStyle('Danger')
          );
                  let m = await interaction.reply({ embeds: [tax_embed], components: [row] });
                  let collector = m.createMessageComponentCollector({ filter: i => i.user.id === interaction.user.id, time: 3600000 ,max: 4 })
                  collector.on('collect', async i => {
                    if (i.customId === 'first_embed') {
                            interaction.editReply({ embeds:[mod_embed], components: [row2] })
                            row
                            i.deferUpdate()
                    }
                    if (i.customId === '2_embed') {
                   interaction.editReply({ embeds:[tax_embed], components: [row] })
                      
                            i.deferUpdate()
                    } else {
                      return;
                    }
                }); 
              } catch (err) {
                console.log(err)
        }
}}