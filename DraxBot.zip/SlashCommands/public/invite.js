const { SlashCommandBuilder, ChatInputCommandInteraction, Client, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js')

module.exports = {
    data: new SlashCommandBuilder()

    .setName('invite')
    .setDescription(`Invite DraxBot to your Discord Server`),

    /**
     * @param { Client } client
     * @param { ChatInputCommandInteraction } interaction
     */

    async execute(interaction, client) {
        const OAuth2 = `https://discord.com/api/oauth2/authorize?1209902696124129430=${client.user.id}&permissions=8&scope=applications.commands%20bot`

        interaction.reply({ content: `Link invite Bot`, components: [new ActionRowBuilder() .addComponents(new ButtonBuilder() .setStyle(ButtonStyle.Link) .setLabel(`Invite ${client.user.username}`) .setURL(OAuth2))] })
    }
}