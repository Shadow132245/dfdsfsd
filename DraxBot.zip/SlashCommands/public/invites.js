const { SlashCommandBuilder,PermissionFlagsBits } = require('discord.js')
var { inviteTracker } = require("discord-inviter")
module.exports = { 
    data: new SlashCommandBuilder()
    .setName('invites')
    .setDescription('Invites Memeber')
    .addUserOption(Option => 
        Option
        .setName('user')
        .setDescription('select user')
        .setRequired(false)),

        async execute(interaction, client) {
            let user = interaction.options.getMember('user') || interaction.member;
            let invite = await inviteTracker.getMemberInvites(user);
            interaction.reply(`> ${user.user.tag} Has Got ${invite.count} Invite(s)`);
        }
}