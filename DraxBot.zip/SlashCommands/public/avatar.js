const { Client, ChatInputCommandInteraction, SlashCommandBuilder, EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js')

module.exports = {
    data: new SlashCommandBuilder()
    
	.setName('avatar')
    .setDescription('Get a user\'s avatar.')
    .addUserOption((Option) => Option
    .setName('user')
    .setDescription('Select The User')
    .setRequired(false)),

    /**
     * @param { Client } Client
     * @param { ChatInputCommandInteraction } Interaction
     */

    async execute(Interaction, Client) {
        const User = Interaction.options.getUser('user') || Interaction.user;
        const Embed = new EmbedBuilder()
            .setColor('Random')
            .setImage(User.displayAvatarURL({ size: 4096 }))
            .setFooter({ text: `Requested by ${Interaction.user.tag}`, iconURL: Interaction.user.displayAvatarURL() })
        const Row = new ActionRowBuilder()
            .addComponents(new ButtonBuilder() .setStyle(ButtonStyle.Link) .setLabel('Avatar URL') .setURL(User.displayAvatarURL({ size: 4096 })))
        Interaction.reply({ embeds: [Embed], components: [Row] })
    }
}