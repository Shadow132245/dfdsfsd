const { SlashCommandBuilder,EmbedBuilder, Client,GatewayIntentBits, client } = require('discord.js');

const { version: djsversion } = require("discord.js");

const { version } = require("../../package.json");

module.exports = {
    data: new SlashCommandBuilder()
    .setName('about')
    .setDescription('Information about the bot'),
    async execute(interaction, client) {
        let embed = new EmbedBuilder()
          .setAuthor({ name: 'Information Bot:', iconURL: 
           client.user.displayAvatarURL({dynamic : true})})
          .setColor(`Random`)
          .setDescription(`**DraxBot Multipu commands bot packed with features
Simply add the bot to your server and use /help for a list of commands**\n\n> [Support Bot](https://discord.gg/AqV3hFznHp)\n> [Invite Bot](https://discord.com/api/oauth2/authorize?1208860743504494662=${client.user.id}&permissions=8&scope=applications.commands%20bot)`)
.setFooter({text: `Requested by ${interaction.user.username}` , iconURL : interaction.user.displayAvatarURL({dynamic: true})})
.addFields(
		{ name: '<:name:1060278925126799440> Name:', value: `${client.user.tag}`, inline: true },
		{ name: '<:id:1060278927932805170> Id:', value: `${client.user.id}`, inline: true },
    { name: '<:users:1060278929962831903> Users:', value: `${client.guilds.cache.reduce((a, b) => a + b.memberCount, 0).toLocaleString()}`, inline: true },
    { name: '<:counts:1060278937952993360> Guilds Count', value: `${client.guilds.cache.size.toLocaleString()}`, inline: true },
    { name: '<:version:1060278939534245898> Version:', value: `${version}`, inline: true },
    { name: '<:username:1060280571340804096> Bot Name:', value: `${client.user.username}`, inline: true },
    { name: '<:discordjs:1060278942256341052> Discord.js', value: `${djsversion}`, inline: true },
    { name: '<:nodejs:1060278935075692634> Node.js Version:', value: `${process.version}`, inline: true },
    { name: '<:platform:1060278933326675999> Platform:', value: `${process.platform}`, inline: true },
    { name: '<:ping:1060279153343086683> Ping:', value: `${client.ws.ping}ms`, inline: true },
	)
.setTimestamp()

 interaction.reply({embeds: [embed] })
    }
}