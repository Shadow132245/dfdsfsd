const { SlashCommandBuilder ,EmbedBuilder} = require("discord.js");
const moment = require('moment')
module.exports = {
    data: new SlashCommandBuilder()
    .setName('inrole')
    .setDescription('Get information about a role')
    .addRoleOption(Option => 
        Option
        .setName('role')
        .setDescription('Select Role')
        .setRequired(true)),

        async execute(interaction) {
            try {
                let role = interaction.options.getRole('role')
                let map = interaction.guild.roles.cache.get(role.id).members.map(rr => `**<@${rr.id}> ( ${rr.id} )**`).join("\n")
                    
               interaction.reply({ embeds: [       
                 new EmbedBuilder()
                .setColor(`Random`)
                .setDescription(`**Role Name : **\`${role.name}\`
             **Members Count Have This Role :** \`${interaction.guild.roles.cache.get(role.id).members.size}\`
            
             **Members :** ${map}
            
            **Role Is Created At :**\`${moment(role.createdAt).format('DD/MM/YYYY h:mm')}\``)
                 .setTimestamp()
                 .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true}) })
                 .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
             ], split: true})
            
            
            } catch (err) {
                  console.log(err)
        }
}}