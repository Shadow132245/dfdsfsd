const { SlashCommandBuilder,EmbedBuilder, Client,GatewayIntentBits, client } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
   
    .setName('ping')
   
    .setDescription('Check the Ping'),

    async execute(interaction, client) {
        interaction.reply({ content: `🏓 Latency: \`${Math.round(client.ws.ping)}ms\`` });
        }
    }