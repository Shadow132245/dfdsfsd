const { SlashCommandBuilder, Client, CommandInteraction, ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder, ComponentType } = require("discord.js");
const fs = require("node:fs");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("help")
    .setDescription("Helps You In The Bot Commands"),

  /**
    * @param {CommandInteraction} interaction
    * @param {Client} client
  */
  async execute(interaction, client) {
    let publicFiles = fs.readdirSync("./SlashCommands/public").filter(file => file.endsWith(".js") && !file.includes("help"));
    let publicCmds = "";
   let moderationFiles = fs.readdirSync("./SlashCommands/moderation").filter(file => file.endsWith(".js") && !file.includes("help"));
    let moderationCmds = "";
    let protectionFiles = fs.readdirSync("./SlashCommands/protection").filter(file => file.endsWith(".js") && !file.includes("help"));
    let protectionCmds = "";
    let settingsFiles = fs.readdirSync("./SlashCommands/settings").filter(file => file.endsWith(".js") && !file.includes("help"));
    let settingsCmds = "";

    
    for (const file of publicFiles) {
      let command = require(`../public/${file}`);
      publicCmds += `**${command.data.name}** - \`${command.data.description}\`\n`
    }
    for (const file of moderationFiles) {
      let command = require(`../moderation/${file}`);
      moderationCmds += `**${command.data.name}** - \`${command.data.description}\`\n`
    }
    for (const file of protectionFiles) {
      let command = require(`../protection/${file}`);
      protectionCmds += `**${command.data.name}** - \`${command.data.description}\`\n`
    }
    for (const file of settingsFiles) {
      let command = require(`../settings/${file}`);
      settingsCmds += `**${command.data.name}** - \`${command.data.description}\`\n`
    }

    const row = new ActionRowBuilder()
      .addComponents(
        new StringSelectMenuBuilder()
          .setCustomId("help")
          .setPlaceholder("Nothing Selected")
          .addOptions(
            {
              label: "Home",
              description: 'To view the information',
              emoji: '1055301953804062790',
              value: "home_page",
            },
            {
              label: "Public Commands",
              description: 'To view the public commands',
              emoji: '1055303688018735114',
              value: "public_commands",
            },
            {
              label: "Moderation Commands",
              description: 'To view the moderation commands',
              emoji: '1055304323300601857',
              value: "moderation_commands",
            },
            {
              label: "Protection Commands",
              description: 'To view the protection commands',
              emoji: '1055305044955779072',
              value: "protection_commands",
            },
            {
              label: "Settings Commands",
              description: 'To view the settings commands',
              emoji: '1060009809002373182',
              value: "settings_commands",
            }
          )
      )
    
    let home = new EmbedBuilder()
      .setColor("#FFFF00")
      .setDescription(`**Please Select a category to view all its commands of ${client.user.username}**`)
    await interaction.reply({ embeds: [home], components: [row], ephemeral: true })

    const filter = i => i.user.id === interaction.user.id;

    const collector = interaction.channel.createMessageComponentCollector({ filter, time: 120000, componentType: ComponentType.SelectMenu })

    collector.on("collect", async (i) => {
      let publicEmbed = new EmbedBuilder()
        .setColor("#FFFF00")
        .setDescription(publicCmds)
      let moderationEmbed = new EmbedBuilder()
        .setColor("#FFFF00")
        .setDescription(moderationCmds)
      let protectionEmbed = new EmbedBuilder()
        .setColor("#FFFF00")
        .setDescription(protectionCmds)
      let settingsEmbed = new EmbedBuilder()
        .setColor("#FFFF00")
        .setDescription(settingsCmds)

      let value = i.values[0];

      if (value == "home_page") {
        await i.update({ embeds: [home], components: [row] })
      } else if (value == "public_commands") {
        await i.update({ embeds: [publicEmbed], components: [row] })
      } else if (value == "moderation_commands") {
        await i.update({ embeds: [moderationEmbed], components: [row] })
      } else if (value == "protection_commands") {
        await i.update({ embeds: [protectionEmbed], components: [row] })
      } else if (value == "settings_commands") {
        await i.update({ embeds: [settingsEmbed], components: [row] })
      }
    })
    
  }
}