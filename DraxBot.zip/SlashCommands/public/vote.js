const { SlashCommandBuilder, ChatInputCommandInteraction, Client, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js')

module.exports = {
    data: new SlashCommandBuilder()

    .setName('vote')
    .setDescription(`Gives you the vote Link For DraxBot`),

    /**
     * @param { Client } client
     * @param { ChatInputCommandInteraction } interaction
    */

    async execute(interaction, client) {
        const VoteLink = `https://discord.com/api/oauth2/authorize?1208860743504494662=${client.user.id}&permissions=8&scope=applications.commands%20bot`

        interaction.reply({ content: `Enjoying the DraxBot\nClick __Vote For__ to vote for me on top.gg`, components: [new ActionRowBuilder() .addComponents(new ButtonBuilder() .setStyle(ButtonStyle.Link) .setLabel(`Vote For ${client.user.username}`) .setURL(VoteLink))] })
    }
}