const fs = require("node:fs");
const path = require("node:path");
const db = require("pro.db");
const express = require('express');

const app = express();

app.get('/', (req, res) => {
  res.send('Hello Express app!')
});

app.listen(3000, () => {
  console.log('Server Started');
});

require('events').EventEmitter.defaultMaxListeners = 9999999;
const { Client, Events, EmbedBuilder, GatewayIntentBits,AttachmentBuilder, Collection, ActionRowBuilder, ButtonBuilder, ButtonStyle, Message } = require('discord.js');
const client = new Client({
	intents: [
		GatewayIntentBits.Guilds,
  	GatewayIntentBits.GuildBans,
		GatewayIntentBits.GuildMessages,
		GatewayIntentBits.GuildPresences,
		GatewayIntentBits.MessageContent,
  	GatewayIntentBits.GuildVoiceStates
	]
})

process.on("uncaughtException" , error => {
return;
})

process.on("unhandledRejection" , error => {
return;
})

process.on("rejectionHandled", error => {
return;
})

client.Success = '<:Success:1060203853108219936>';
client.Failed  = '<:Failed:1060203668869234748>';

client.ŚÇ  = new Collection();
client.Çɱɗ = new Collection()

module.exports = client;

fs.readdirSync('./Handlers').forEach(async Handler => {
	require(`./Handlers/${Handler}`)(client)
})

client.on('messageCreate', async Message => {
  try {
if(db.get(`whitelist_${Message.guild.id}`).includes(Message.author.id)) return;
let Db = db.get(`ANTILINKS_${Message.guild.id}`)
if (Db === true) {
 if (Message.content.includes('www.') || Message.content.includes('discord.gg') || Message.content.includes('https://') || Message.content.includes('http://') || Message.content.includes('.xyz') || Message.content.includes('youtube') || Message.content.includes('.php')) {  
   await Message.member.timeout(60_0000)
   Message.delete()
  Message.channel.send({ content: `Links is Blocked Here ${Message.author}` })
   Message.author.send('You have been given as much time as possible due to sending links')
       }}
    }catch (err) {return;}
   })

client.on('guildMemberAdd', async Member => {
if(db.get(`whitelist_${Member.guild.id}`).includes(Member.author.id)) return;
const Antibot = await db.fetch(`Antibots_${Member.guild.id}`)
if (Antibot !== true) return;
if(Member.user.bot) return Member.ban({ reason: 'Protection By DraxBot' });
});

client.on("messageCreate", async (message) => {
  try {
  if(db.get(`whitelist_${message.guild.id}`).includes(message.author.id)) return;
  if (db.get(`AntiBadwords_${message.guild.id}`) === true) {
  let Badwords = await db.fetch(`badwords_${message.guild.id}`);
    if (!Badwords || Badwords === null) return;
    for (let i = 0; i < Badwords.length; i++) {
      if (message.content.toLowerCase().includes(Badwords[i].trim())) {
      message.member.timeout(60_0000)
        return message.delete();
      }
    }
          }}
catch (err) {return;}
})    

client.on("messageCreate", message => { 
 if(message.content === `<@${client.user.id}>`) {
const embed = new EmbedBuilder()
   .setDescription(`**Welcome im ${client.user.username} My Slash Command /**`)
   .setTitle(`Bot Info My ${client.user.username}`)
   .setColor(`#ffff00`)
   .setAuthor({name: message.guild.name,iconURL: message.guild.iconURL({dynamic:true})})
   .setFooter({ text: `Requested by ${message.author.tag}` , iconURL: 
    message.author.displayAvatarURL({dynamic:true})})
   .setTimestamp()
   message.reply({ embeds: [embed] })
   }
});

client.on("messageCreate", message => {
  if (message.mentions.members.size > 0) {
    if (message.author.bot) return;
    message.mentions.members.forEach(member => {
      if (member.nickname && member.nickname.startsWith("[AFK] ")) {
       const reason =  db.get(`AFK_${member.id}`)
        message.channel.send(`**${member.displayName} is Reason : ${reason}.**`);
      }
    });
  }
});

client.on("messageCreate", async message => {
  if (!message.guild || message.author.bot) return;
  if (message.member.displayName && message.member.displayName.startsWith("[AFK] ")) {
      message.member.setNickname(message.member.displayName.replace("[AFK] ", ""));
      const welcome = await message.reply("👋 Welcome Back, you're no Longer AFK");
      setTimeout(() => {
     db.delete(`AFK_${message.member.id}`)
      welcome.delete()
      }, 5000)
  }
});

client.on('messageCreate', async message => {
       if(message.content.startsWith('join')) {
        if(!message.member.permissions.has('ManageGuild')) return message.channel.send({ content: `:x: ${message.author}, This Command Required **ManageGuild** Permission` })
        await client.emit('guildMemberAdd', message.member)
        message.react('✅');
    }
});

client.on('messageCreate', async message => {
       if(message.content.startsWith('leave')) {
        if(!message.member.permissions.has('ManageGuild')) return message.channel.send({ content: `:x: ${message.author}, This Command Required **ManageGuild** Permission` })
        await client.emit('guildMemberRemove', message.member)
        message.react('✅')
    }
});

let r1 = "1207369496923349032" // ايدي رول الاولة
let r2 = "" // ايدي رول ثانية
let r3 = "" // ايدي رول ثالثة
 
const link = "https://cdn.discordapp.com/attachments/1206729563930107914/1209231038308556890/65d25dfc35c1ff0fa7e83209.gif?ex=65e62b29&is=65d3b629&hm=3993e933492e194ccd50ecbbb00d3bc387e5bd1feab86aa012d74c198f993bb0&" // رابط خط سيرفرك
client.on('messageCreate', message => {
  if(!`899373670131195955`.includes(message.author.id)) return;
        if(message.content.toLowerCase().startsWith("get-started")) {
                let emo = new EmbedBuilder()
                .setAuthor({ name: `Information`, iconURL: message.guild.iconURL({dynamic: true}) })
                .setColor("#ffff00")
                .setDescription(`__English__\n> **Follow one of the buttons in these messages below to get more information**\n\n__Arabic__\n> **اتبع أحد الأزرار في هذه الرسائل أدناه للحصول على مزيد من المعلومات**`)
                .setImage(`https://cdn.discordapp.com/attachments/1054715486035771462/1056018706532139058/D.png`)
                const kk = new ActionRowBuilder()
                .addComponents(
                        new ButtonBuilder()
                        .setCustomId("English")
                        .setLabel("English")
                        .setEmoji("1064872183337320510")
                        .setStyle("Success"),
                        new ButtonBuilder()
                        .setCustomId("Arabic")
                        .setLabel("Arabic")
                        .setEmoji("1064870192821317743")
                        .setStyle("Primary"),
                        new ButtonBuilder()
                        .setCustomId("inv")
                        .setLabel("Invite Member")
                        .setEmoji("1023798644824088708")
                        .setStyle("Secondary"),
                )
                message.channel.send({embeds: [emo], components: [kk]})
        }
});
 
 
client.on('interactionCreate', interaction => {
        if(!interaction.isButton()) return;
        if(interaction.customId === "English") {
               const embed = new EmbedBuilder()
                .setColor("#ffff00")
                .setAuthor({ name: `Information`, iconURL: interaction.guild.iconURL({dynamic: true}) })
                .setDescription(`Dedicated server to inquire about the bot or if you have a problem with our bot`)
                .setThumbnail(interaction.guild.iconURL({dynamic: true}))
                .setImage(link)
     let row = new ActionRowBuilder()
    .addComponents(
        new ButtonBuilder()
        .setCustomId('Get Start_en')                  
        .setLabel('Get Started')             
        .setStyle("Success"),            
        new ButtonBuilder()
        .setCustomId('rules_en')                   
        .setLabel('View Rules')
        .setStyle("Danger"),         
        new ButtonBuilder()
        .setCustomId('Role_en')                   
        .setLabel('Select Roles')
        .setStyle("Primary"),   
        new ButtonBuilder()
        .setCustomId('Important_en')
        .setLabel('Important')
        .setDisabled(true)
        .setStyle("Secondary"),   
      )
      interaction.reply({ embeds: [embed], components: [row], ephemeral: true})
        }
});
 
 
 
client.on('interactionCreate', interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'Get Start_en') {
            const momn = new EmbedBuilder()
            .setDescription("Features the bot Logs , Moderation , Protection , Apps , Team DraxBot is working on developing the bot to the best thing , DraxBot does what the most popular bots do but does it better, faster , Good luck and enjoy DraxBot")
            .setColor("#ffff00")
            .setImage(link)
            .setThumbnail(`${interaction.guild.iconURL({ dynamic: true})}`)
            .setAuthor({ name: `Get Started`, iconURL: interaction.guild.iconURL({dynamic: true}) })
          interaction.reply({ embeds: [momn], ephemeral : true});
  }
})
client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'rules_en') {
            const momn2 = new EmbedBuilder()
            .setDescription(`1 - Do not mention the developers in chat, this bothers them.

2 - Do not promote or share your Discord server links here, this results in an immediate ban!

3 - Do not discuss topics that create controversies such as politics and religions.

4 - Do not go on talking about other Discord bots in this server, this place is only meant for DraxBot

5 - Do not share any Nsfw (Not Safe For Work) content here

6 - If you got any inquiries or issues regarding DraxBot, please consider mentioning the 1206717657081061411 role only once,

7 - Repeating messages, images, or mentions is not allowed in here, it is considered as spam and results in getting you muted

8 - Do not mention other Discord server names or talk about their staff, this results in you being warned`)
            .setColor("#ffff00")
            .setImage(link)
            .setThumbnail(`${interaction.guild.iconURL({ dynamic: true})}`)
            .setAuthor({ name: `Rules`, iconURL: interaction.guild.iconURL({dynamic: true}) })
          interaction.reply({ embeds: [momn2], ephemeral : true});
  }
})
 
 
client.on('interactionCreate', interaction => {
    if(!interaction.isButton()) return;
        if(interaction.customId === 'Role_en') {
                                     let er = new EmbedBuilder()
                                     .setDescription(`News Notifications\n**Get pinged for all announcements, including events, promotions, and other important updates**\n\nStatus Notifications\n**Get pinged for announcements about DraxBot status and maintenance**\n\nUpdates Notifications\n**Get pinged for announcements about new features and changes to DraxBot**`)
                                     .setImage(link)
                                     .setColor("#ffff00")
                                     .setThumbnail(`${interaction.guild.iconURL({ dynamic: true})}`)
                                     .setAuthor({ name: `Select Roles`, iconURL: interaction.guild.iconURL({dynamic: true}) })
                                  let ro = new ActionRowBuilder()
    .addComponents(
        new ButtonBuilder()
        .setCustomId('rol_en')                  
        .setLabel('News Notifications')             
        .setStyle("Secondary"),            
        new ButtonBuilder()
        .setCustomId('role2_en')                   
        .setLabel('Status Notifications')
        .setStyle("Secondary"),         
        new ButtonBuilder()
        .setCustomId('role3_en')                   
        .setLabel('Updates Notifications')
        .setStyle("Secondary"), 
      )
                let r2o = new ActionRowBuilder()
    .addComponents(
        new ButtonBuilder()
        .setCustomId('all_en')                  
        .setLabel('Get All Role')             
        .setStyle("Success"),            
        new ButtonBuilder()
        .setCustomId('allR_en')                   
        .setLabel('Remove All Role')
        .setStyle("Danger"),         
        )
interaction.reply({embeds: [er], components: [ro, r2o], ephemeral: true})
                             }
})
 
client.on('interactionCreate', interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'rol_en') {
         if(!interaction.member.roles.cache.has(r1)) {
            interaction.member.roles.add(r1)
            interaction.reply({content: `**✅ Add <@&${r1}>**`, ephemeral: true, fetchReply: true});
        }
        if (interaction.member.roles.cache.has(r1)) {
            interaction.member.roles.remove(r1) 
            interaction.reply({content: `**✅ Remove <@&${r1}>**`, ephemeral: true, fetchReply: true});
        }
    }
});
 
client.on('interactionCreate', interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'role2_en') {
         if(!interaction.member.roles.cache.has(r2)) {
            interaction.member.roles.add(r2)
            interaction.reply({content: `**✅ Add <@&${r2}>**`, ephemeral: true, fetchReply: true});
        }
        if (interaction.member.roles.cache.has(r2)) {
            interaction.member.roles.remove(r2) 
           interaction.reply({content: `**✅ Remove <@&${r2}>**`, ephemeral: true, fetchReply: true});
        }
    }
});
 
client.on('interactionCreate', interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'role3_en') {
         if(!interaction.member.roles.cache.has(r3)) {
            interaction.member.roles.add(r3)
            interaction.reply({content: `**✅ Add <@&${r3}>**`, ephemeral: true, fetchReply: true});
        }
        if (interaction.member.roles.cache.has(r3)) {
            interaction.member.roles.remove(r3) 
            interaction.reply({content: `**✅ Remove <@&${r3}>**`, ephemeral: true, fetchReply: true});
        }
    }
});
 
client.on('interactionCreate', interaction => {
        if(!interaction.isButton()) return;
        if(interaction.customId === 'all_en') {
             interaction.member.roles.add(r1)
             interaction.member.roles.add(r2)
             interaction.member.roles.add(r3)
             interaction.reply({content: `**All Roles Have Been Taken  ✅**`, ephemeral: true})
        }
});
 
client.on('interactionCreate', interaction => {
        if(!interaction.isButton()) return;
        if(interaction.customId === 'allR_en') {
             interaction.member.roles.remove(r1)
             interaction.member.roles.remove(r2)
             interaction.member.roles.remove(r3)
             interaction.reply({content: `** All Roles Have Been Removed ✅**`, ephemeral: true})
        }
});
 
client.on('interactionCreate', interaction => {
        if(!interaction.isButton()) return;
        if(interaction.customId === 'Important_en') {
            const momn3 = new EmbedBuilder()
            .setDescription("استبدل هاذي الكتابه ب اشياء مهمه باللغه الانجليزيه")
            .setColor("#2f3136")
            .setImage(link)
            .setThumbnail(`${interaction.guild.iconURL({ dynamic: true})}`)
            .setAuthor({ name: `Important`, iconURL: interaction.guild.iconURL({dynamic: true}) })
          interaction.reply({ embeds: [momn3], ephemeral : true});
  }
})
 
client.on('interactionCreate', interaction => {
        if(!interaction.isButton()) return;
        if(interaction.customId === "Arabic") {
               const embed = new EmbedBuilder()
                .setColor("#2f3136")
                .setAuthor({ name: `معلومات`, iconURL: interaction.guild.iconURL({dynamic: true}) })
                .setDescription(`خادم مخصص للاستعلام عن الروبوت أو إذا كان لديك مشكلة مع الروبوت الخاص بنا`)
                .setThumbnail(interaction.guild.iconURL({dynamic: true}))
                .setImage(link)
     let row = new ActionRowBuilder()
    .addComponents(
        new ButtonBuilder()
        .setCustomId('Get Start_ar')                  
        .setLabel('هيا نبدأ')             
        .setStyle("Success"),            
        new ButtonBuilder()
        .setCustomId('rules_ar')                   
        .setLabel('عرض القوانين')
        .setStyle("Danger"),         
        new ButtonBuilder()
        .setCustomId('Role_ar')                   
        .setLabel('اختيار الرتب')
        .setStyle("Primary"),   
        new ButtonBuilder()
        .setCustomId('Important_ar')                   
        .setLabel('مهم جدأ')
        .setDisabled(true)
        .setStyle("Secondary"),   
      )
      interaction.reply({ embeds: [embed], components: [row], ephemeral: true})
        }
});
 
 
 
         client.on('interactionCreate', interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'Get Start_ar') {
            const momn = new EmbedBuilder()
            .setDescription("ميزات الروبوت بسجلات ، والاعتدال ، والحماية ، والتطبيقات ، ويعمل تيم دراكس بوت على تطوير الروبوت إلى أفضل شيء ، ويقوم دراكس بوت بما تفعله أشهر الروبوتات ولكنه يفعل ذلك بشكل أفضل ، وأسرع ، ونتمنى لك التوفيق والاستمتاع بـ دراكس بوت")
            .setColor("#ffff00")
            .setImage(link)
            .setThumbnail(`${interaction.guild.iconURL({ dynamic: true})}`)
            .setAuthor({ name: `لنبدأ`, iconURL: interaction.guild.iconURL({dynamic: true}) })
          interaction.reply({ embeds: [momn], ephemeral : true});
  }
})
                 client.on('interactionCreate', async interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'rules_ar') {
            const momn2 = new EmbedBuilder()
            .setDescription(`القانون الاول : لا تذكر المطورين في الدردشة فهذا يزعجهم

القانون الثاني : لا تروج أو تشارك روابط خادم الديسكورد هنا ، فهذا يؤدي إلى حظر فوري

القانون الثالث : لا تناقش مواضيع تثير الجدل كالسياسة والأديان

القانون الرابع : لا تستمر في الحديث عن روبوتات الديسكورد الأخرى في هذا الخادم ، فهذا المكان مخصص لـ ديزل بوت فقط

القانون الخامس : لا تشارك أي محتوى Nsfw (غير آمن للعمل) هنا

القانون السادس : إذا كان لديك أي استفسارات أو مشاكل بخصوص دراكس بوت ، يرجى مراعاة ذكر <@&1206717657081061411> مرة واحدة فقط ،

القانون السابع : لا يُسمح بتكرار الرسائل أو الصور أو الإشارات هنا ، فهو يعتبر بريدًا عشوائيًا ويؤدي إلى كتم صوتك

القانون الثامن : لا تذكر أسماء خوادم الديسكورد الأخرى أو تتحدث عن موظفيها ، فهذا يؤدي إلى تحذيرك`)
            .setColor("#ffff00")
            .setImage(link)
            .setThumbnail(`${interaction.guild.iconURL({ dynamic: true})}`)
            .setAuthor({ name: `القوانين`, iconURL: interaction.guild.iconURL({dynamic: true}) })
          interaction.reply({ embeds: [momn2], ephemeral : true});
  }
})
 
 
client.on('interactionCreate', interaction => {
    if(!interaction.isButton()) return;
        if(interaction.customId === 'Role_ar') {
                                     let er = new EmbedBuilder()
                                     .setDescription(`اشعارات الأخبار\n**احصل على تنبيه لجميع الإعلانات ، بما في ذلك الأحداث والعروض الترويجية والتحديثات المهمة الأخرى**\n\nاشعارات حالة البوت\n**احصل على أخبار حول حالة دراكس بوت وصيانتها**\n\nاشعارات تحديثات البوت\n**احصل على تنبيه للإعلانات حول الميزات والتغييرات الجديدة على دراكس بوت**`)
                                     .setImage(link)
                                     .setColor("#ffff00")
                                     .setThumbnail(`${interaction.guild.iconURL({ dynamic: true})}`)
                                     .setAuthor({ name: `اختيار الرتب`, iconURL: interaction.guild.iconURL({dynamic: true}) })
                                  let ro = new ActionRowBuilder()
    .addComponents(
        new ButtonBuilder()
        .setCustomId('rol_ar')                  
        .setLabel('اشعارات الأخبار')             
        .setStyle("Secondary"),            
        new ButtonBuilder()
        .setCustomId('role2_ar')                   
        .setLabel('اشعارات حالة البوت')
        .setStyle("Secondary"),         
        new ButtonBuilder()
        .setCustomId('role3_ar')                   
        .setLabel('اشعارات تحديثات البوت')
        .setStyle("Secondary"),
      )
                let r2o = new ActionRowBuilder()
    .addComponents(
        new ButtonBuilder()
        .setCustomId('all_ar')                  
        .setLabel('Get All Role')             
        .setStyle("Success"),            
        new ButtonBuilder()
        .setCustomId('allR_ar')                   
        .setLabel('Remove All Role')
        .setStyle("Danger"),         
        )
interaction.reply({embeds: [er], components: [ro, r2o], ephemeral: true})
                             }
})
 
client.on('interactionCreate', interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'rol_ar') {
         if(!interaction.member.roles.cache.has(r1)) {
            interaction.member.roles.add(r1)
            interaction.reply({content: `**✅ اضافة <@&${r1}>**`, ephemeral: true, fetchReply: true});
        }
        if (interaction.member.roles.cache.has(r1)) {
            interaction.member.roles.remove(r1) 
            interaction.reply({content: `**✅ ازالة <@&${r1}>**`, ephemeral: true, fetchReply: true});
        }
    }
});
 
client.on('interactionCreate', interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'role2_ar') {
         if(!interaction.member.roles.cache.has(r2)) {
            interaction.member.roles.add(r2)
            interaction.reply({content: `**✅ اضافة <@&${r2}>**`, ephemeral: true, fetchReply: true});
        }
        if (interaction.member.roles.cache.has(r2)) {
            interaction.member.roles.remove(r2) 
           interaction.reply({content: `**✅ ازالة <@&${r2}>**`, ephemeral: true, fetchReply: true});
        }
    }
});
 
client.on('interactionCreate', interaction => {
    if (!interaction.isButton()) return;
    if (interaction.customId === 'role3_ar') {
         if(!interaction.member.roles.cache.has(r3)) {
            interaction.member.roles.add(r3)
            interaction.reply({content: `**✅ اضافة <@&${r3}>**`, ephemeral: true, fetchReply: true});
        }
        if (interaction.member.roles.cache.has(r3)) {
            interaction.member.roles.remove(r3) 
            interaction.reply({content: `**✅ ازالة <@&${r3}>**`, ephemeral: true, fetchReply: true});
        }
    }
});
 
client.on('interactionCreate', interaction => {
        if(!interaction.isButton()) return;
        if(interaction.customId === 'all_ar') {
             interaction.member.roles.add(r1)
             interaction.member.roles.add(r2)
             interaction.member.roles.add(r3)
             interaction.reply({content: `** تم أخذ جميع الرولات ✅**`, ephemeral: true})
        }
});
 
client.on('interactionCreate', interaction => {
        if(!interaction.isButton()) return;
        if(interaction.customId === 'allR_ar') {
             interaction.member.roles.remove(r1)
             interaction.member.roles.remove(r2)
             interaction.member.roles.remove(r3)
          
            interaction.reply({content: `** تم ازالة جميع الرولات ✅**`, ephemeral: true})
        }
});
 
client.on('interactionCreate', interaction => {
        if(!interaction.isButton()) return;
        if(interaction.customId === 'Important_ar') {
            const momn3 = new EmbedBuilder()
            .setDescription("استبدل هاذي الكتابه ب اشياء مهمه باللغه العربيه")
            .setColor("#2f3136")
            .setImage(link)
            .setThumbnail(`${interaction.guild.iconURL({ dynamic: true})}`)
            .setAuthor({ name: `مهم`, iconURL: interaction.guild.iconURL({dynamic: true}) })
          interaction.reply({ embeds: [momn3], ephemeral : true});
  }
})
 
 
client.on('interactionCreate', interaction => {
        if(!interaction.isButton()) return;
        if(interaction.customId === 'inv') {
                interaction.reply({content: `Server DraxBot Support : https://discord.gg/AqV3hFznHp\nInvite Bot : https://discord.com/api/oauth2/authorize?client_id=1209902696124129430&permissions=8&scope=bot`, ephemeral: true})
        }
});

client.login(process.env.token).catch((err) => {
  console.log(err)
});