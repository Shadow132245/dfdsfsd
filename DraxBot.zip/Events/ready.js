const { Events, ActivityType } = require('discord.js')
const Client = require('../index.js')

Client.on(Events.ClientReady, async (c) => {
console.log(require('chalk').blue.bold(`${Client.user.username} is Ready !`))
Client.user.setPresence({
  activities: [{ name: `/help | DraxBot Beta`, type: ActivityType.Watching }],
  status: `${process.env.status}`,
});
});