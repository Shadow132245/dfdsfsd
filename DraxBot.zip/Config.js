exports.ClientId = '1209902696124129430';
exports.OwnersId = ['1207369496923349032', '', '', ''];
exports.ClientPrefix = 'd'